import { BoldPipe } from './bold.pipe';

describe('BoldPipe', () => {
  it('create an instance', () => {
    const pipe = new BoldPipe();
    expect(pipe).toBeTruthy();
  });
});
