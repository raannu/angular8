import { WelcomePipe } from './welcome.pipe';

describe('WelcomePipe', () => {
  it('create an instance', () => {
    const pipe = new WelcomePipe();
    expect(pipe).toBeTruthy();
  });
});
