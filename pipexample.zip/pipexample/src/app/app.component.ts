import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  //encapsulation:ViewEncapsulation.Emulated // it will show the same output becase of No shadow DOM
  //encapsulation:ViewEncapsulation.Native // it will show parents css on child component due to Shadow DOM
  //encapsulation:ViewEncapsulation.None 

})
export class AppComponent {
  title = 'RAMESH GUPTA';
  pdSize:number=100;
  colorBorder = 'red'
  date = new Date();
  Employee = {
    Name:"Ajeet Kumar Singh",
    MobileNo : 555665655
  }
}
