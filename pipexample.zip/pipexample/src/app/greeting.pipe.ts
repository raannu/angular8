import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'greeting'
})
export class GreetingPipe implements PipeTransform {
  
  transform(value: any, ...args: any[]): any {
    var greet: string;
    let date = new Date();
    let hours = date.getHours();
    if(hours<12)
    return greet='Good Morning '+value;
    else if(hours>=12 && hours<17)
    return greet= 'Good Afternoon';
    else if(hours>17 && hours < 22)
    return greet='Good Evening '+value;
    else 
    return greet='Good Night '+value;
    //return greet;
  }

}
